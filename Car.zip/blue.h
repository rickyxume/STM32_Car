#ifndef __BLUE_H
#define	__BLUE_H


#include "stm32f10x.h"
#include <stdio.h>
#include "delay.h"
#include "motor.h"
void USART_Config(void);
void Send_Data(char);
#endif 

